#ifndef SYMBOL_TABLE_H_
#define SYMBOL_TABLE_H_

#define MAX_CONTEXT 1000

typedef struct st_bucket_ *ST_Bucket;
typedef struct st_ *ST;

#endif